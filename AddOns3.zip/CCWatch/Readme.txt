I don't know anything about programming addons...but the original author, Elwen/maniac91 stated that he won't be able to continue adding effects and developing it any further.
So someone needs to do it, in this release I added MANY effects that were missing,
and fixed some effects that had wrong duration.
Also, the addon only had 2 Buffs, so I had to add many, it serves as a good enemy buffwatch now too.
Credit goes to Elwen/maniac91 for making this great mod and Vector- for giving the base mod(StunWatch)!!!
And to me for adding effects, it really was lots of work considering so many effects were missing and translations being incorrect ^^"
Basically I had to completely rewrite it ("\(-.-)

Because I'm German I unfortunately cannot add French translations - If you want to supply French translations please message me: ICQ 173192620

If you find some stuff unnecessary then tell me, and explain why.

-phoenixfire2001

PS: I couldn't test many of them, so, sorry, if some things don't work correctly, I'd be glad if you tell me here and tell me the correct string!