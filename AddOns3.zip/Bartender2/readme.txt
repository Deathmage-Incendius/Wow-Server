Bartender2 is an AddOn to move Blizzards default buttons. It has several
frames which can be moved around screen and locked into the place you wan't.
There is also a feature to hide the frames you don't need.

Get it from: http://svn.wowace.com/root/trunk/Bartender2/
Alternative: http://wow.reaktio.net/addons (might not always be up to date)

Here's some Extra modules people have made for Bartender2:
http://svn.wowace.com/root/trunk/Bartender2_BindingSwap/
http://svn.wowace.com/root/trunk/Bartender2_Dreamlayout/
http://svn.wowace.com/root/trunk/Bartender2_Pagemaster/
http://svn.wowace.com/root/trunk/Bartender2_HunterBars
http://svn.wowace.com/root/trunk/FuBartender2/

If you like GUI configs, take the FuBartender2! It's FuBar plugin by
nevcairiel!

** Remember to enable ALL Blizzard Bars in Interface Options! **
Otherwise you can't drag&drop spells in the empty bars Smiley

just do /bar and see the list of commands available :)

If you're updating from older Bartender2, It would be wise to remove your
layout-config completely. Some things have been changed and the profiles
might not work the way they were planned!