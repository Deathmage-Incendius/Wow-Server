--[[
	Bagnon Main Options Localization file
--]]

--[[
	German
--]]

if ( GetLocale() == "deDE" ) then
	BAGNON_MAINOPTIONS_SHOW = "Zeige";
	return;
end