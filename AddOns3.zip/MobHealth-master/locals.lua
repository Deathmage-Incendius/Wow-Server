--[[ $Id: locals.lua 14223 2006-10-18 10:49:11Z hshh $ ]]--

MOBHEALTH_UnitCreatureType_Demon="Demon"
MOBHEALTH_UnitCreatureType_Beast="Beast"

if GetLocale() == "zhCN" then
	MOBHEALTH_UnitCreatureType_Demon="恶魔"
	MOBHEALTH_UnitCreatureType_Beast="野兽"
end