--[[
--
--	DamageMeters Localization Data (FRENCH)
--

    French translation by Kurty and eXess.  Many thanks!
    
--]]
if ( GetLocale() == "frFR" ) then

-- *** This is a placeholder file: please download the official French version. ***

end -- if ( GetLocale() == "frFR" ) 
